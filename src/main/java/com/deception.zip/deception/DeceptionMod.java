package com.deception;

import com.deception.command.ModCommands;
import com.deception.game.GameManager;
import com.deception.init.ClueHoverOverlay;
import com.deception.init.ModBlocks;
import com.deception.init.ModClientSetup;
import com.deception.init.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DeceptionMod.MOD_ID)
public class DeceptionMod {

    public static final String MOD_ID = "deception";

    public DeceptionMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        com.deception.network.ModNetworking.register();

        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModItems.CREATIVE_TABS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(ModClientSetup::onClientSetup);
        modEventBus.addListener(ModClientSetup::registerOverlays);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        ModCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            GameManager.get().tick();
        }
    }

    // server mau berhenti (stop command, restart, crash-shutdown, dll) --
    // kalo game lagi jalan, stopgame dulu (restore arena, balikin
    // pvp/difficulty/gamemode) biar gak ninggalin arena dalam kondisi
    // "kepasang" pas server nyala lagi.
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        GameManager.get().forceCleanupOnStartup(event.getServer());
    }
    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        if (GameManager.get().getState() != GameManager.State.IDLE) {
            GameManager.get().stopGame(event.getServer());
        }
    }

    // player rejoin pas game lagi jalan -- kalo dia punya cluster, respawn
    // kepalanya pake GameProfile asli dia yang sekarang online (ganti yang
    // tadinya kepasang pake profile placeholder/skin default pas dia masih
    // offline waktu arena di-build).
    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            GameManager.get().refreshOwnerHeadSkin(serverPlayer.getServer(), serverPlayer.getUUID());
        }
    }

    // Murderer klik kanan block means/clue (ClueBlock) di cluster dia
    // sendiri -- pilih item asli, backing-nya berubah jadi hijau.
    @SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;

        if (GameManager.get().onMurdererClickClue(player, level, event.getPos())) {
            event.setCanceled(true);
        }
    }

    // Murderer klik kanan (di udara) pake kepala konfirmasi -- kunci
    // pilihan item yang udah dipilih lewat onRightClickBlock di atas.
    @SubscribeEvent
    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        if (GameManager.get().onMurdererConfirmHead(player, event.getItemStack())) {
            event.setCanceled(true);
        }
    }
}