package com.deception.game;

import com.deception.command.RoleDescriptions;
import com.deception.init.ClusterData;
import com.deception.init.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraftforge.registries.RegistryObject;
import com.deception.block.ClueBlock;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraftforge.common.ForgeMod;
import org.joml.Quaternionf;

import java.util.*;

public class GameManager {

    public enum State {
        IDLE, COUNTDOWN, SHUFFLE, NIGHT, DISCUSS, RUNNING
    }

    private static final GameManager INSTANCE = new GameManager();

    public static GameManager get() {
        return INSTANCE;
    }

    private State state = State.IDLE;
    private final LinkedHashSet<UUID> registeredPlayers = new LinkedHashSet<>();
    private final Map<UUID, String> playerNames = new HashMap<>();
    public static final Map<BlockPos, ClusterData> CLUSTERS = new HashMap<>();
    private final Map<UUID, Role> roleAssignments = new HashMap<>();

    // override manual dari /customrole; null = pakai default tabel komposisi
    private Boolean accompliceOverride = null;
    private Boolean witnessOverride = null;

    // "random" atau nama player spesifik
    private String forensicScientistMode = "random";

    private int discussTimerSeconds = 600; // default 10 menit

    // ---------- Countdown (title/subtitle only, gak ada spam chat) ----------
    private static final int COUNTDOWN_SECONDS = 5;
    private int countdownTicks = 0;
    private int lastCountdownSecondShown = -1;

    // ---------- Shuffle role (animasi "ngocok" peran) ----------
    private static final int SHUFFLE_DURATION_TICKS = 100; // 5 detik
    private int shuffleTicksLeft = 0;
    private List<Role> activeRolePool = new ArrayList<>();

    private int discussTicksLeft = 0;

    // ---------- Night sequence (tutup mata -> murderer/accomplice pilih item -> witness liat) ----------
    private static final int NIGHT_CLOSE_HOLD = 60;    // 3 detik "semua tutup mata" sebelum killer dibangunin
    private static final int NIGHT_KILLERS_ACT = 100;  // 5 detik murderer(+accomplice) "milih item"
    private static final int NIGHT_WITNESS_HOLD = 60;  // 3 detik witness liat killer nyala (glowing)
    private static final int NIGHT_WAKE_HOLD = 20;     // 1 detik title "semua bangun" sebelum lanjut discuss

    private int nightTicksElapsed;
    private int nightKillersWakeAt;
    private int nightWitnessRevealAt;
    private int nightWitnessEndAt;
    private int nightWakeAllAt;
    private int nightDoneAt;
    private final Set<UUID> nightBlindfolded = new HashSet<>();
    private final List<UUID> nightKillers = new ArrayList<>();
    private UUID nightWitnessUuid;
    private boolean murdererConfirmed = false;

    // ---------- Murderer pilih item means/clue asli pas night ----------
    // posisi block BACKING (bukan block clue-nya sendiri) yang lagi hijau
    // (pilihan aktif murderer sekarang) -- null kalo belum milih apa-apa.
    // Single-select: tiap klik kanan item baru bakal balikin backing lama
    // ke warna asli (merah=means/biru=clue) dulu sebelum yang baru dijadiin hijau.
    private BlockPos murdererSelectedBackingPos = null;

    // reverse-lookup posisi block means/clue -> UUID pemilik cluster-nya,
    // biar bisa validasi murderer cuma boleh milih dari cluster DIA SENDIRI.
    // Diisi bareng CLUSTERS pas buildClusters(), dibersihin bareng restoreArena().
    private final Map<BlockPos, UUID> clusterOwnerByPos = new HashMap<>();

    private static final String MURDERER_CONFIRM_HEAD_TEXTURE =
            "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYjVhM2I0OWJlZWMzYWIyM2FlMGI2MGRhYjU2ZTljYzhmYTE2NzY5YTI1ODMwYjVkOGQ2YzQ2Mzc4ZjU0NDMwIn19fQ==";
    // tag NBT penanda item ini "kepala konfirmasi", biar RightClickItem
    // handler gak salah nangkep kepala player biasa yang laen.
    private static final String CONFIRM_HEAD_TAG = "DeceptionConfirmHead";

    // ---------- Overlay hitam full-screen (dibaca langsung dari client, lihat init/BlindfoldOverlay) ----------
    // NOTE: kurva animasi blink+close & tick-transition udah PINDAH ke
    // client (lihat init/BlindfoldClientState), karena project ini jalan
    // pake dedicated server terpisah dari client -- gak ada shared memory,
    // jadi state visual harus dikirim lewat packet (network/BlindfoldStatePacket),
    // bukan dihitung di server terus dibaca "langsung" dari client.
    private long globalTickCounter = 0;


    private MinecraftServer serverRef;
    private final Random shuffleRandom = new Random();
    private final List<UUID> spawnedHeadEntities = new ArrayList<>();
    private final Map<UUID, HeadPlacement> headPlacementByOwner = new HashMap<>();
    private final Map<UUID, List<UUID>> headEntitiesByOwner = new HashMap<>();
    private Difficulty previousDifficulty;

    // ---------- Teleport + pasang clue/means random pas countdown selesai ----------
    private static final BlockPos ARENA_TELEPORT_POS = new BlockPos(119, -59, 179);

    // tiap dinding: sumbu yang jalan sepanjang dinding, koordinat tetap
    // (fixed axis), titik tengah, panjang, dan arah hadap block (ke dalam
    // ruangan) pas ditempel.
    private static final int MEANS_Y = -57; // baris atas
    private static final int CLUE_Y = -58;  // baris bawah
    private static final int HEAD_Y = MEANS_Y + 1; // baris kepala player, nempel di atas means

    // maksimal cluster per dinding kiri/kanan (dinding belakang cuma kepake
    // kalau kiri+kanan udah penuh). Total maksimal 4+4+4 = 12, nyamain max
    // player deception (4-12). tiap cluster lebar 4 block (4 means berjejer
    // di atas, 4 clue berjejer di bawah)
    private static final int MAX_CLUSTERS_PER_SIDE_WALL = 4;
    private static final int CLUSTER_WIDTH = 4;

    // jarak "maju" dikit dari permukaan dinding biar kepala gak z-fighting
    // sama block dinding solid di belakangnya
    private static final float HEAD_SURFACE_INSET = 0.06F;

    private record WallSpec(String label, boolean alongX, int fixedCoord, int center, int length, Direction facing) {}

    private record HeadPlacement(WallSpec wall, int[] columns) {}

    private static final WallSpec[] ARENA_WALLS = new WallSpec[]{
            // kiri: sepanjang X, z tetap 189, tengah x=119, panjang 21, hadap ke dalam (utara)
            new WallSpec("kiri", true, 189, 120, 21, Direction.NORTH),
            // kanan: sepanjang X, z tetap 169, tengah x=119, panjang 21, hadap ke dalam (selatan)
            new WallSpec("kanan", true, 169, 120, 21, Direction.SOUTH),
            // belakang: sepanjang Z, x tetap 130, tengah z=179, panjang 21, hadap ke dalam (barat)
            new WallSpec("belakang", false, 130, 179, 21, Direction.WEST),
    };

    /**
     * Susun clusterCount cluster selebar CLUSTER_WIDTH block, dikasih gap
     * eksplisit (minimal 2 block) antar cluster yang berdampingan, terus
     * seluruh barisan (cluster + gap) dimentokin ke ujung BELAKANG dinding
     * (offset positif, sisi deket dinding belakang) -- bukan di-center.
     * Hasil: array of int[], tiap elemen isinya CLUSTER_WIDTH offset kolom
     * yang berdampingan buat 1 cluster.
     */
    private static int[][] clusterColumnGroups(int length, int clusterCount) {
        if (clusterCount <= 0) return new int[0][];

        // gap dihitung eksplisit dari sisa ruang dibagi rata ke celah
        // antar cluster -- minimal 2 block, biar keliatan jelas ada jarak
        // (dulu bisa jatuh ke 1 block doang, keliatan dempet)
        int gap = clusterCount > 1
                ? 1 : 0;
        int totalWidth = clusterCount * CLUSTER_WIDTH + gap * (clusterCount - 1);

        // mentokin ke ujung belakang (offset positif), bukan center
        int startCol = -totalWidth / 2;

        int[][] groups = new int[clusterCount][CLUSTER_WIDTH];
        for (int i = 0; i < clusterCount; i++) {
            int colStart = startCol + i * (CLUSTER_WIDTH + gap);
            for (int j = 0; j < CLUSTER_WIDTH; j++) {
                groups[i][j] = colStart + j;
            }
        }
        return groups;
    }

    /**
     * Berapa cluster yang kepake di tiap dinding (kiri, kanan, belakang)
     * berdasarkan JUMLAH PLAYER — bukan fixed 4/dinding lagi. Kiri & kanan
     * diisi rata dulu (maks MAX_CLUSTERS_PER_SIDE_WALL / dinding), sisanya
     * baru dilempar ke belakang. Kalau ganjil, kiri kebagian 1 lebih banyak.
     * Contoh: 4 player -> [2, 2, 0]. 9 player -> [4, 4, 1].
     */
    private static int[] computeClusterCountsPerWall(int totalPlayers) {
        int kiri = Math.min(MAX_CLUSTERS_PER_SIDE_WALL, (int) Math.ceil(totalPlayers / 2.0));
        int kanan = Math.min(MAX_CLUSTERS_PER_SIDE_WALL, totalPlayers - kiri);
        int belakang = totalPlayers - kiri - kanan;
        return new int[]{kiri, kanan, belakang}; // urutannya harus ngikutin ARENA_WALLS
    }

    // ---------- Registrasi ----------

    public boolean registerPlayer(MinecraftServer server, String name) {
        ServerPlayer player = server.getPlayerList().getPlayerByName(name);
        if (player == null) {
            return false;
        }
        registeredPlayers.add(player.getUUID());
        playerNames.put(player.getUUID(), name);
        return true;
    }

    public boolean unregisterPlayer(String name) {
        UUID target = null;
        for (Map.Entry<UUID, String> entry : playerNames.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(name)) {
                target = entry.getKey();
                break;
            }
        }
        if (target == null) return false;
        registeredPlayers.remove(target);
        roleAssignments.remove(target);
        return true;
    }

    public int registerAll(MinecraftServer server) {
        int count = 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            registeredPlayers.add(player.getUUID());
            playerNames.put(player.getUUID(), player.getGameProfile().getName());
            count++;
        }
        return count;
    }

    public int unregisterAll() {
        int count = registeredPlayers.size();
        registeredPlayers.clear();
        roleAssignments.clear();
        return count;
    }

    public Set<UUID> getRegisteredPlayers() {
        return registeredPlayers;
    }

    // ---------- Custom role toggle ----------

    public void setCustomRole(Role role, boolean enabled) {
        if (role == Role.ACCOMPLICE) {
            accompliceOverride = enabled;
        } else if (role == Role.WITNESS) {
            witnessOverride = enabled;
        }
    }

    // ---------- Forensic scientist & timer ----------

    public void setForensicScientistMode(String mode) {
        this.forensicScientistMode = mode;
    }

    public void setDiscussTimerSeconds(int seconds) {
        this.discussTimerSeconds = seconds;
    }

    // ---------- Role info / debug ----------

    public Map<UUID, Role> getRoleAssignments() {
        return roleAssignments;
    }

    public String getPlayerName(UUID uuid) {
        return playerNames.getOrDefault(uuid, uuid.toString());
    }

    // ---------- Start / stop ----------

    /**
     * Alasan spesifik kenapa /deception startgame gagal, biar command-nya
     * bisa kasih pesan yang jelas (bukan cuma "gagal start" generik).
     */
    public enum StartResult {
        OK, ALREADY_RUNNING, INVALID_PLAYER_COUNT, PLAYER_OFFLINE
    }

    public StartResult startGame(MinecraftServer server) {
        if (state != State.IDLE) {
            return StartResult.ALREADY_RUNNING;
        }
        if (registeredPlayers.size() < 4 || registeredPlayers.size() > 12) {
            return StartResult.INVALID_PLAYER_COUNT;
        }
        if (!getOfflineRegisteredPlayerNames(server).isEmpty()) {
            return StartResult.PLAYER_OFFLINE;
        }
        this.serverRef = server;
        this.state = State.COUNTDOWN;
        this.countdownTicks = COUNTDOWN_SECONDS * 20;
        this.lastCountdownSecondShown = -1;
        server.setPvpAllowed(false);
        this.previousDifficulty = server.getWorldData().getDifficulty();
        server.setDifficulty(Difficulty.PEACEFUL, true);

        for (UUID uuid : registeredPlayers) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player != null) {
                player.setGameMode(GameType.ADVENTURE);
                AttributeInstance blockReach = player.getAttribute(ForgeMod.BLOCK_REACH.get());
                if (blockReach != null) {
                    blockReach.setBaseValue(30.0D);
                }
            }
        }
        return StartResult.OK;
    }

    /**
     * Nama-nama player yang teregistrasi tapi lagi offline -- dipake buat
     * validasi startgame (gak boleh start kalo ada yang offline) sama buat
     * pesan error spesifiknya.
     */
    public List<String> getOfflineRegisteredPlayerNames(MinecraftServer server) {
        List<String> offline = new ArrayList<>();
        for (UUID uuid : registeredPlayers) {
            if (server.getPlayerList().getPlayer(uuid) == null) {
                offline.add(getPlayerName(uuid));
            }
        }
        return offline;
    }

    /**
     * Baris "Nama (online)" / "Nama (offline)" buat tiap player teregistrasi
     * -- dipake command /deception listplayer.
     */
    public List<String> getRegisteredPlayerStatusLines(MinecraftServer server) {
        List<String> lines = new ArrayList<>();
        for (UUID uuid : registeredPlayers) {
            boolean online = server.getPlayerList().getPlayer(uuid) != null;
            lines.add(getPlayerName(uuid) + (online ? " (online)" : " (offline)"));
        }
        return lines;
    }

    public void stopGame(MinecraftServer server) {
        abortGame(server, Component.literal("Game dihentikan oleh admin.").withStyle(ChatFormatting.RED));
    }

    private void abortGame(MinecraftServer server, Component reason) {
        this.state = State.IDLE;
        this.roleAssignments.clear();
        this.countdownTicks = 0;
        this.lastCountdownSecondShown = -1;
        this.shuffleTicksLeft = 0;
        this.discussTicksLeft = 0;
        this.nightTicksElapsed = 0;
        this.murdererConfirmed = false;
        this.murdererSelectedBackingPos = null;

        MinecraftServer target = server != null ? server : serverRef;
        if (target != null) {
            target.setPvpAllowed(true);
            if (previousDifficulty != null) {
                target.setDifficulty(previousDifficulty, true);
            }
            restoreArena(target);
            for (UUID uuid : registeredPlayers) {
                ServerPlayer player = target.getPlayerList().getPlayer(uuid);
                if (player != null) {
                    player.setGameMode(GameType.SURVIVAL);
                    removeBlindfold(player);
                    removeGlow(player);
                    AttributeInstance blockReach = player.getAttribute(ForgeMod.BLOCK_REACH.get());
                    if (blockReach != null) {
                        blockReach.setBaseValue(blockReach.getAttribute().getDefaultValue());
                    }
                }
            }
            nightBlindfolded.clear();
            nightKillers.clear();
            nightWitnessUuid = null;
            broadcast(target, reason);
        }
    }

    /**
     * Balikin arena ke kondisi kosong: hapus semua block means/clue +
     * backing merah/biru di 3 dinding (diganti deepslate_tiles), despawn
     * semua item display kepala player yang pernah dipasang, dan bersihin
     * data cluster (buat hover overlay) biar gak nyangkut data lama.
     */
    private void restoreArena(MinecraftServer server) {
        ServerLevel level = server.overworld();

        for (UUID headId : spawnedHeadEntities) {
            var entity = level.getEntity(headId);
            if (entity != null) {
                entity.discard();
            }
        }
        for (Entity entity : level.getEntities().getAll()) {
            if (entity.getTags().contains("deception_display")) {
                entity.discard();
            }
        }
        spawnedHeadEntities.clear();
        headPlacementByOwner.clear();
        headEntitiesByOwner.clear();
        CLUSTERS.clear();
        clusterOwnerByPos.clear();

        resetArenaBlocks(level);
    }

    /**
     * Reset semua block means/clue + backing di 3 dinding balik ke kondisi
     * kosong (air + deepslate_tiles) -- MURNI dari koordinat ARENA_WALLS,
     * gak gantung ke state/list in-memory apapun. Dipake dari restoreArena
     * (pas /deception stopgame) DAN forceCleanupOnStartup (pas server baru
     * nyala, buat jaga-jaga kalo server sebelumnya mati gak lewat /stop
     * yang bersih -- misal cmd window ditutup paksa -- jadi state di-memory
     * ilang duluan sebelum sempet restoreArena kepanggil).
     */
    private void resetArenaBlocks(ServerLevel level) {
        BlockState deepslateTiles = Blocks.DEEPSLATE_TILES.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (WallSpec wall : ARENA_WALLS) {
            Direction backingDir = wall.facing().getOpposite();
            int half = wall.length() / 2;
            for (int offset = -half; offset <= half; offset++) {
                int x = wall.alongX() ? wall.center() + offset : wall.fixedCoord();
                int z = wall.alongX() ? wall.fixedCoord() : wall.center() + offset;

                BlockPos meansPos = new BlockPos(x, MEANS_Y, z);
                BlockPos cluePos = new BlockPos(x, CLUE_Y, z);
                level.setBlock(meansPos, air, 3);
                level.setBlock(cluePos, air, 3);
                level.setBlock(meansPos.relative(backingDir), deepslateTiles, 3);
                level.setBlock(cluePos.relative(backingDir), deepslateTiles, 3);
            }
        }
    }

    /**
     * AABB yang meliputi seluruh ruangan arena (3 dinding + sedikit
     * padding), dihitung dari ARENA_WALLS -- dipake forceCleanupOnStartup
     * buat nyari entity display (kepala/nametag) yang nyasar ketinggalan
     * dari sesi sebelumnya.
     */
    private AABB computeArenaBounds() {
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
        double minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (WallSpec wall : ARENA_WALLS) {
            if (wall.alongX()) {
                minX = Math.min(minX, wall.center() - wall.length() / 2.0);
                maxX = Math.max(maxX, wall.center() + wall.length() / 2.0);
                minZ = Math.min(minZ, wall.fixedCoord());
                maxZ = Math.max(maxZ, wall.fixedCoord());
            } else {
                minZ = Math.min(minZ, wall.center() - wall.length() / 2.0);
                maxZ = Math.max(maxZ, wall.center() + wall.length() / 2.0);
                minX = Math.min(minX, wall.fixedCoord());
                maxX = Math.max(maxX, wall.fixedCoord());
            }
        }
        double pad = 3;
        return new AABB(minX - pad, CLUE_Y - 3, minZ - pad, maxX + pad, HEAD_Y + 3, maxZ + pad);
    }

    /**
     * Safety net dipanggil pas server baru nyala (lihat DeceptionMod,
     * ServerStartingEvent). Kalo server sebelumnya mati gak lewat /stop
     * yang bersih (cmd window ditutup paksa, crash, dll), semua state
     * in-memory (spawnedHeadEntities, CLUSTERS, dst) ilang duluan sebelum
     * sempet restoreArena() kepanggil -- makanya blok means/clue + kepala
     * player masih nyangkut pas server nyala lagi. Method ini beresin itu
     * TANPA gantung ke state in-memory: block direset dari koordinat
     * ARENA_WALLS langsung, dan entity display (kepala/nametag) yang
     * ketinggalan dicari & dibuang dari world berdasarkan area arena.
     */
    public void forceCleanupOnStartup(MinecraftServer server) {
        this.state = State.IDLE;
        ServerLevel level = server.overworld();

        resetArenaBlocks(level);

        for (UUID headId : spawnedHeadEntities) {
            var entity = level.getEntity(headId);
            if (entity != null) {
                entity.discard();
            }
        }
        // spawnedHeadEntities pasti kosong abis restart (in-memory, ilang
        // pas JVM mati) -- makanya cleanup yang beneran diandelin ke tag
        // "deception_display" yang ke-nempel di entity-nya sendiri pas
        // dispawn (lihat spawnOwnerHead), bukan ke list di atas.
        for (Entity entity : level.getEntities().getAll()) {
            if (entity.getTags().contains("deception_display")) {
                entity.discard();
            }
        }

        spawnedHeadEntities.clear();
        headPlacementByOwner.clear();
        headEntitiesByOwner.clear();
        CLUSTERS.clear();
        clusterOwnerByPos.clear();
    }

    /**
     * Hitung role apa aja yang bakal aktif di game ini (berdasarkan jumlah
     * player teregistrasi + override /customrole), dipakai buat animasi
     * kocokan biar cuma nge-flash role yang beneran ada, bukan semua enum.
     */
    private List<Role> computeActiveRolePool() {
        RoleComposition composition = new RoleComposition(registeredPlayers.size());
        if (accompliceOverride != null) composition.setAccompliceEnabled(accompliceOverride);
        if (witnessOverride != null) composition.setWitnessEnabled(witnessOverride);

        Map<Role, Integer> counts = composition.resolve();
        List<Role> pool = new ArrayList<>();
        for (Map.Entry<Role, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > 0) {
                pool.add(entry.getKey());
            }
        }
        return pool;
    }

    /**
     * Hitung role assignment (data doang, TANPA reveal ke player) --
     * dipanggil SEBELUM teleportPlayersAndDecorateArena() biar pas build
     * arena udah tau siapa Forensic Scientist-nya (cluster means/clue
     * dia di-skip, gak ditaro di dinding).
     */
    private void computeRoleAssignments() {
        RoleComposition composition = new RoleComposition(registeredPlayers.size());
        if (accompliceOverride != null) composition.setAccompliceEnabled(accompliceOverride);
        if (witnessOverride != null) composition.setWitnessEnabled(witnessOverride);

        Map<Role, Integer> counts = composition.resolve();

        List<UUID> pool = new ArrayList<>(registeredPlayers);
        Collections.shuffle(pool);

        roleAssignments.clear();
        int index = 0;
        for (Map.Entry<Role, Integer> entry : counts.entrySet()) {
            for (int i = 0; i < entry.getValue(); i++) {
                if (index >= pool.size()) break;
                roleAssignments.put(pool.get(index), entry.getKey());
                index++;
            }
        }

        // Override forensic scientist kalau diminta spesifik (bukan random)
        if (!"random".equalsIgnoreCase(forensicScientistMode)) {
            UUID targetFs = null;
            for (Map.Entry<UUID, String> e : playerNames.entrySet()) {
                if (e.getValue().equalsIgnoreCase(forensicScientistMode) && registeredPlayers.contains(e.getKey())) {
                    targetFs = e.getKey();
                    break;
                }
            }
            if (targetFs != null) {
                UUID currentFs = null;
                for (Map.Entry<UUID, Role> e : roleAssignments.entrySet()) {
                    if (e.getValue() == Role.FORENSIC_SCIENTIST) {
                        currentFs = e.getKey();
                        break;
                    }
                }
                if (currentFs != null && !currentFs.equals(targetFs)) {
                    Role targetOldRole = roleAssignments.get(targetFs);
                    roleAssignments.put(targetFs, Role.FORENSIC_SCIENTIST);
                    roleAssignments.put(currentFs, targetOldRole);
                }
            }
        }
    }

    /**
     * Reveal role ke tiap player (title + chat) -- dipanggil pas animasi
     * shuffle selesai. roleAssignments udah keisi dari computeRoleAssignments().
     */
    private void revealRoles(MinecraftServer server) {
        for (Map.Entry<UUID, Role> entry : roleAssignments.entrySet()) {
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player != null) {
                Component title = Component.literal("Peran kamu!").withStyle(ChatFormatting.GOLD);
                Component subtitle = Component.literal(entry.getValue().getDisplayName())
                        .withStyle(ChatFormatting.YELLOW);
                sendTitle(player, title, subtitle, 5, 50, 15);
                playSoundTo(player, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.MASTER, 3.0F, 1.0F);

                player.sendSystemMessage(Component.literal("Peran kamu adalah: " + entry.getValue().getDisplayName())
                        .withStyle(ChatFormatting.GOLD));
                player.sendSystemMessage(Component.literal(RoleDescriptions.get(entry.getValue()))
                        .withStyle(ChatFormatting.GRAY));
            }
        }
    }

    /**
     * Delay sebelum blindfold beneran dipasang -- title "Semua orang tutup
     * mata" muncul dulu SENDIRIAN (mata masih kebuka) selama ini, baru abis
     * itu mata mulai nutup (lihat tickNightSequence).
     */
    private static final int NIGHT_PRECLOSE_DELAY = 60; // 3 detik

    private final Set<UUID> nightPendingBlindfold = new HashSet<>();

    /**
     * Mulai sequence "tutup mata" abis role di-reveal: title diumumin dulu
     * (mata masih kebuka), baru NIGHT_PRECLOSE_DELAY tick kemudian semua
     * orang KECUALI Forensic Scientist beneran dipasangin blindfold
     * (noteblock di kepala + overlay eyelid client), jadwal
     * checkpoint-checkpoint sequence-nya (kapan killer bangun, kapan
     * witness liat, kapan semua bangun) dihitung sekali di sini, jalannya
     * dieksekusi tiap tick lewat tickNightSequence().
     */
    private void startNightSequence(MinecraftServer server) {
        this.state = State.NIGHT;
        this.nightTicksElapsed = 0;
        this.murdererConfirmed = false;
        this.murdererSelectedBackingPos = null;

        UUID fsUuid = null;
        nightKillers.clear();
        nightWitnessUuid = null;
        for (Map.Entry<UUID, Role> e : roleAssignments.entrySet()) {
            if (e.getValue() == Role.FORENSIC_SCIENTIST) fsUuid = e.getKey();
            else if (e.getValue() == Role.MURDERER || e.getValue() == Role.ACCOMPLICE) nightKillers.add(e.getKey());
            else if (e.getValue() == Role.WITNESS) nightWitnessUuid = e.getKey();
        }
        boolean hasWitness = nightWitnessUuid != null;

        // Semua checkpoint digeser NIGHT_PRECLOSE_DELAY tick, soalnya mata
        // baru MULAI nutup di tick itu (bukan dari tick 0 lagi).
        nightKillersWakeAt = NIGHT_PRECLOSE_DELAY + NIGHT_CLOSE_HOLD;
        // Checkpoint witness-reveal: normalnya nunggu murderer confirm
        // (di-set ulang lebih awal lewat onMurdererConfirmHead), tapi
        // dikasih fallback finite di sini (BUKAN Integer.MAX_VALUE lagi --
        // itu bikin overflow negatif di nightDoneAt pas gaada Witness)
        // biar tetep lanjut walaupun murderer gak confirm sama sekali.
        nightWitnessRevealAt = nightKillersWakeAt + NIGHT_KILLERS_ACT;
        nightWitnessEndAt = nightWitnessRevealAt + (hasWitness ? NIGHT_WITNESS_HOLD : 0);
        nightWakeAllAt = nightWitnessEndAt;
        nightDoneAt = nightWakeAllAt + NIGHT_WAKE_HOLD;

        // Belum dipasang beneran di sini -- cuma dicatet siapa aja yang
        // NANTI harus di-blindfold, dieksekusi di tickNightSequence pas
        // nightTicksElapsed == NIGHT_PRECLOSE_DELAY.
        nightBlindfolded.clear();
        nightPendingBlindfold.clear();
        for (UUID uuid : registeredPlayers) {
            if (uuid.equals(fsUuid)) continue;
            nightPendingBlindfold.add(uuid);
        }

        // Broadcast ke SEMUA orang (bukan cuma yang bakal blindfolded) biar
        // semua tau lagi fase "tutup mata" -- title-nya nahan sampe abis
        // periode preclose + close-hold, jadi masih keliatan pas mata udah
        // mulai/lagi nutup juga (Z-nya di atas eyelid).
        com.deception.network.ModNetworking.broadcastNightTitle(
                Component.literal("Semua orang tutup mata").withStyle(ChatFormatting.DARK_GRAY),
                Component.empty(), 10, NIGHT_PRECLOSE_DELAY + NIGHT_CLOSE_HOLD - 20, 10);
    }

    /**
     * Dipanggil tiap tick pas state == NIGHT. Checkpoint-checkpoint-nya
     * dihitung sekali di startNightSequence(), di sini tinggal dibandingin
     * ke nightTicksElapsed -- jadi tiap aksi cuma kejalanin PERSIS SEKALI
     * pas tick-nya kena, bukan diulang-ulang tiap tick.
     */
    private void tickNightSequence() {
        nightTicksElapsed++;

        // Safety-net: noteblock helm-nya gak pake enchant curse of binding
        // lagi (biar gak ada efek kilau/foil), jadi di sini kita paksa balik
        // kepasang tiap tick kalo somehow player berhasil ngelepasnya.
        for (UUID uuid : nightBlindfolded) {
            ServerPlayer bp = serverRef.getPlayerList().getPlayer(uuid);
            if (bp != null && bp.getItemBySlot(EquipmentSlot.HEAD).getItem() != Items.NOTE_BLOCK) {
                bp.setItemSlot(EquipmentSlot.HEAD, createBlindfoldItem());
            }
        }

        // Habis periode "title doang" (mata masih kebuka), baru beneran
        // pasangin blindfold ke semua orang yang tercatet di
        // nightPendingBlindfold -- ini yang mulai jalanin animasi eyelid
        // closing di client (lihat BlindfoldClientState).
        if (nightTicksElapsed == NIGHT_PRECLOSE_DELAY) {
            for (UUID uuid : nightPendingBlindfold) {
                ServerPlayer p = serverRef.getPlayerList().getPlayer(uuid);
                if (p != null) {
                    putBlindfold(p);
                    nightBlindfolded.add(uuid);
                }
            }
        }

        if (nightTicksElapsed == nightKillersWakeAt) {
            String killerLabel = nightKillers.size() > 1 ? "Murderer & Accomplice" : "Murderer";
            // Broadcast ke semua orang -- gak nge-reveal SIAPA killer-nya,
            // cuma ngasih tau lagi fase apa (kayak moderator ngomong keras).
            com.deception.network.ModNetworking.broadcastNightTitle(
                    Component.literal(killerLabel + " buka mata").withStyle(ChatFormatting.RED),
                    Component.empty(), 10, 40, 10);
            for (UUID uuid : nightKillers) {
                ServerPlayer p = serverRef.getPlayerList().getPlayer(uuid);
                if (p != null) {
                    removeBlindfold(p);
                    nightBlindfolded.remove(uuid);
                    // cuma Murderer (bukan Accomplice) yang dapet kepala
                    // konfirmasi -- dia yang milih means/clue asli.
                    if (roleAssignments.get(uuid) == Role.MURDERER) {
                        giveConfirmHead(p);
                    }
                }
            }
            // Actionbar "menunggu" dikirim SEKALI aja (persisten di client,
            // animasi titiknya jalan sendiri) -- BUKAN di-refresh berkala.
            com.deception.network.ModNetworking.broadcastNightActionBar(
                    Component.literal("Menunggu murderer memilih item").withStyle(ChatFormatting.RED));
        }

        if (nightTicksElapsed == nightWitnessRevealAt) {
            // Fase milih-item killer abis -- clear actionbar-nya (regardless
            // ada witness atau kagak, soalnya nightWitnessRevealAt tetep
            // kehitung walaupun gak ada witness di game ini).
            com.deception.network.ModNetworking.broadcastNightActionBar(Component.empty());
        }

        if (nightTicksElapsed == nightWitnessRevealAt && nightWitnessUuid != null) {
            ServerPlayer witnessPlayer = serverRef.getPlayerList().getPlayer(nightWitnessUuid);
            if (witnessPlayer != null) {
                removeBlindfold(witnessPlayer);
                nightBlindfolded.remove(nightWitnessUuid);
            }
            com.deception.network.ModNetworking.broadcastNightTitle(
                    Component.literal("Perhatikan baik-baik").withStyle(ChatFormatting.AQUA),
                    Component.empty(), 10, NIGHT_WITNESS_HOLD, 10);
            for (UUID uuid : nightKillers) {
                ServerPlayer p = serverRef.getPlayerList().getPlayer(uuid);
                if (p != null) applyGlow(p);
            }
        }

        if (nightTicksElapsed == nightWitnessEndAt && nightWitnessUuid != null) {
            for (UUID uuid : nightKillers) {
                ServerPlayer p = serverRef.getPlayerList().getPlayer(uuid);
                if (p != null) removeGlow(p);
            }
            ServerPlayer witnessPlayer = serverRef.getPlayerList().getPlayer(nightWitnessUuid);
            if (witnessPlayer != null) {
                putBlindfold(witnessPlayer);
                nightBlindfolded.add(nightWitnessUuid);
            }
        }

        if (nightTicksElapsed == nightWakeAllAt) {
            for (UUID uuid : new ArrayList<>(nightBlindfolded)) {
                ServerPlayer p = serverRef.getPlayerList().getPlayer(uuid);
                if (p != null) removeBlindfold(p);
            }
            nightBlindfolded.clear();
            com.deception.network.ModNetworking.broadcastNightTitle(
                    Component.literal("Semua orang bangun").withStyle(ChatFormatting.GOLD),
                    Component.empty(), 10, NIGHT_WAKE_HOLD, 10);
        }

        if (nightTicksElapsed >= nightDoneAt) {
            state = State.DISCUSS;
            discussTicksLeft = discussTimerSeconds * 20;
            broadcast(serverRef, Component.literal("Diskusi dimulai.").withStyle(ChatFormatting.GREEN));
        }
    }

    /**
     * "Blindfold" = helm NOTE_BLOCK yang GAK PAKE enchant sama sekali
     * (dulu Curse of Binding, tapi itu bikin item-nya ada efek kilau/foil
     * yang gak bisa disembunyiin cuma lewat HideFlags -- HideFlags cuma
     * nyembunyiin TEKS tooltip, bukan efek render foil-nya). "Gak bisa
     * dicopot"-nya sekarang dijamin lewat safety-check tiap tick di
     * tickNightSequence() (re-equip otomatis kalo somehow kelepas), pola
     * yang emang konsisten sama desain tick-driven di seluruh class ini.
     * PLUS ngirim BlindfoldStatePacket ke client biar animasi kelopak
     * mata-nya (init/BlindfoldClientState) mulai jalan -- dikirim lewat
     * packet, BUKAN dibaca "langsung" dari client, karena project ini
     * jalan pake dedicated server yang beda proses/JVM sama client, jadi
     * gak ada shared memory antara GameManager server & client.
     */
    private void putBlindfold(ServerPlayer player) {
        player.setItemSlot(EquipmentSlot.HEAD, createBlindfoldItem());
        com.deception.network.ModNetworking.sendBlindfoldState(player, true);
    }

    private void removeBlindfold(ServerPlayer player) {
        if (player.getItemBySlot(EquipmentSlot.HEAD).getItem() == Items.NOTE_BLOCK) {
            player.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
        }
        com.deception.network.ModNetworking.sendBlindfoldState(player, false);
    }

    private ItemStack createBlindfoldItem() {
        ItemStack helmet = new ItemStack(Items.NOTE_BLOCK);
        helmet.setHoverName(Component.literal("Mata Tertutup").withStyle(ChatFormatting.DARK_GRAY));
        return helmet;
    }

    /**
     * Kepala custom-skin (base64 texture, GameProfile dummy) yang di-give
     * ke inventory Murderer pas dia bangun -- klik kanan di udara buat
     * ngonfirmasi item (means/clue) yang udah dipilih lewat
     * onMurdererClickClue(). Ditandai CONFIRM_HEAD_TAG biar handler-nya
     * gak ketuker sama player head biasa.
     */
    private void giveConfirmHead(ServerPlayer player) {
        ItemStack head = new ItemStack(Items.PLAYER_HEAD);
        head.setHoverName(Component.literal("Konfirmasi Pilihan").withStyle(ChatFormatting.GREEN));

        GameProfile fakeProfile = new GameProfile(UUID.randomUUID(), "confirm");
        fakeProfile.getProperties().put("textures", new Property("textures", MURDERER_CONFIRM_HEAD_TEXTURE));

        CompoundTag tag = head.getOrCreateTag();
        tag.put("SkullOwner", NbtUtils.writeGameProfile(new CompoundTag(), fakeProfile));
        tag.putBoolean(CONFIRM_HEAD_TAG, true);

        player.getInventory().add(head);
    }

    /**
     * Dipanggil dari event handler (lihat DeceptionMod) pas ServerPlayer
     * klik kanan sebuah block. Cuma diproses kalo lagi State.NIGHT, player-
     * nya Murderer, matanya udah kebuka (gak lagi nightBlindfolded), belom
     * confirm, dan block yang diklik itu ClueBlock (means ATAU clue) di
     * cluster MILIK DIA SENDIRI (dicek lewat clusterOwnerByPos).
     * <p>
     * Return true kalo event-nya "di-handle" (caller wajib cancel event
     * block-nya), false kalo gak relevan sama sekali (biarin interaksi
     * block jalan normal).
     */
    public boolean onMurdererClickClue(ServerPlayer player, ServerLevel level, BlockPos pos) {
        if (state != State.NIGHT || murdererConfirmed) return false;

        UUID uuid = player.getUUID();
        if (roleAssignments.get(uuid) != Role.MURDERER) return false;
        if (nightBlindfolded.contains(uuid)) return false;

        BlockState clickedState = level.getBlockState(pos);
        if (!(clickedState.getBlock() instanceof ClueBlock)) return false;

        UUID clusterOwner = clusterOwnerByPos.get(pos);
        if (clusterOwner == null || !clusterOwner.equals(uuid)) {
            player.sendSystemMessage(Component.literal("Itu bukan cluster kamu.").withStyle(ChatFormatting.RED));
            return true;
        }

        if (clickedState.getValue(ClueBlock.FACE) != AttachFace.WALL) return false;
        Direction facing = clickedState.getValue(ClueBlock.FACING);
        BlockPos backingPos = pos.relative(facing.getOpposite());

        // balikin backing pilihan lama ke warna asli (merah/biru) dulu
        // sebelum yang baru dijadiin hijau -- single-select.
        if (murdererSelectedBackingPos != null && !murdererSelectedBackingPos.equals(backingPos)) {
            restoreBacking(level, murdererSelectedBackingPos);
        }

        level.setBlock(backingPos, Blocks.GREEN_CONCRETE.defaultBlockState(), 3);
        murdererSelectedBackingPos = backingPos;

        player.sendSystemMessage(Component.literal("Item dipilih. Klik kanan kepala buat konfirmasi.").withStyle(ChatFormatting.GREEN));
        return true;
    }

    /**
     * Dipanggil dari event handler pas ServerPlayer klik kanan (di udara)
     * pake item yang ditandai CONFIRM_HEAD_TAG. Return true kalo di-handle
     * (caller wajib cancel event item-nya).
     */
    public boolean onMurdererConfirmHead(ServerPlayer player, ItemStack stack) {
        if (!stack.hasTag() || !stack.getTag().getBoolean(CONFIRM_HEAD_TAG)) return false;
        if (state != State.NIGHT) return false;

        UUID uuid = player.getUUID();
        if (roleAssignments.get(uuid) != Role.MURDERER) return false;
        if (murdererConfirmed) return false;

        if (murdererSelectedBackingPos == null) {
            player.sendSystemMessage(Component.literal("Pilih item dulu sebelum konfirmasi.").withStyle(ChatFormatting.RED));
            return true;
        }

        murdererConfirmed = true;
        stack.shrink(1);

        // Kalo murderer confirm SEBELUM fallback timer (NIGHT_KILLERS_ACT)
        // kena, majuin checkpoint witness-reveal ke tick berikutnya --
        // recompute checkpoint2 turunannya (sama persis rumus di
        // startNightSequence) biar witness gak nunggu lama-lama.
        if (nightTicksElapsed < nightWitnessRevealAt) {
            boolean hasWitness = nightWitnessUuid != null;
            nightWitnessRevealAt = nightTicksElapsed + 1;
            nightWitnessEndAt = nightWitnessRevealAt + (hasWitness ? NIGHT_WITNESS_HOLD : 0);
            nightWakeAllAt = nightWitnessEndAt;
            nightDoneAt = nightWakeAllAt + NIGHT_WAKE_HOLD;
        }

        player.sendSystemMessage(Component.literal("Pilihan dikonfirmasi.").withStyle(ChatFormatting.GREEN));
        return true;
    }

    /** Balikin block backing di pos ke warna aslinya (merah=means, biru=clue), ditentuin dari Y-nya. */
    private void restoreBacking(ServerLevel level, BlockPos pos) {
        Block original = pos.getY() == MEANS_Y ? Blocks.RED_CONCRETE : Blocks.BLUE_CONCRETE;
        level.setBlock(pos, original.defaultBlockState(), 3);
    }

    /**
     * Pengganti "scale 2x" -- Minecraft 1.20.1 (vanilla maupun Forge versi
     * ini) gak punya attribute buat resize player (baru ada di vanilla
     * 1.20.5+), jadi dipake efek Glowing (outline nyala tembus tembok)
     * biar witness gampang ngenalin murderer/accomplice.
     */
    private void applyGlow(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.GLOWING, 999999, 0, false, false));
    }

    private void removeGlow(ServerPlayer player) {
        player.removeEffect(MobEffects.GLOWING);
    }

    private void sendTitleTo(MinecraftServer server, Collection<UUID> uuids, Component title, Component subtitle, int fadeIn, int stay, int fadeOut) {
        for (UUID uuid : uuids) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) sendTitle(p, title, subtitle, fadeIn, stay, fadeOut);
        }
    }

    private void sendActionBarTo(MinecraftServer server, Collection<UUID> uuids, Component message) {
        for (UUID uuid : uuids) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) p.connection.send(new ClientboundSetActionBarTextPacket(message));
        }
    }

    /**
     * Title countdown sebelum peran dibagikan. Cuma title + subtitle, gak ada
     * spam chat. Dipanggil sekali tiap detik berubah (bukan tiap tick) biar
     * subtitle-nya keganti angka dengan rapi, plus sound tiap detik.
     */
    private void showCountdownTitle(int secondsLeft) {
        Component title = Component.literal("Game dimulai dalam").withStyle(ChatFormatting.GOLD);
        Component subtitle = Component.literal(String.valueOf(secondsLeft)).withStyle(ChatFormatting.YELLOW);
        for (UUID uuid : registeredPlayers) {
            ServerPlayer player = serverRef.getPlayerList().getPlayer(uuid);
            if (player != null) {
                sendTitle(player, title, subtitle, 0, 20, 5);
                playSoundTo(player, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.MASTER, 3.0F, 1.0F);
            }
        }
    }

    /**
     * Animasi "ngocok" role — dipanggil tiap tick pas SHUFFLE, nge-flash nama
     * role random (dari role yang beneran aktif di game ini) ke subtitle,
     * title-nya tetep "Mengocok Peran". Ada sound tiap flash biar berasa
     * kayak dadu diputer.
     */
    private void spinRoleTitle() {
        if (activeRolePool.isEmpty() || shuffleTicksLeft % 2 != 0) {
            return;
        }

        Role randomRole = activeRolePool.get(shuffleRandom.nextInt(activeRolePool.size()));
        Component subtitle = Component.literal(randomRole.getDisplayName())
                .withStyle(ChatFormatting.YELLOW);

        for (UUID uuid : registeredPlayers) {
            ServerPlayer player = serverRef.getPlayerList().getPlayer(uuid);
            if (player != null) {
                player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
                playSoundTo(player, SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.MASTER, 3.0F, 1.2F);
            }
        }
    }

    private void sendTitle(ServerPlayer player, Component title, Component subtitle, int fadeIn, int stay, int fadeOut) {
        player.connection.send(new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut));
        player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
        player.connection.send(new ClientboundSetTitleTextPacket(title));
    }

    /**
     * Kirim sound YANG CUMA DENGER dia sendiri -- pake Player#playNotifySound,
     * bukan level().playSound(null, ...)/Entity#playSound biasa. Dua itu
     * nge-broadcast sound POSISIONAL ke SEMUA player yang deket (termasuk
     * yang GAK teregistrasi), makanya sebelumnya orang yang gak ke-/regis
     * pun ikut denger sound countdown/kocokan peran. playNotifySound cuma
     * ngirim packet sound ke client player itu doang, gak nge-broadcast ke
     * dunia.
     */
    private void playSoundTo(ServerPlayer player, net.minecraft.sounds.SoundEvent sound, SoundSource source, float volume, float pitch) {
        player.playNotifySound(sound, source, volume, pitch);
    }

    /**
     * Teleport semua player teregistrasi ke titik arena, lalu tempel
     * cluster means (baris atas, y=-57) + clue (baris bawah, y=-58) --
     * TAPI jumlah cluster yang dipasang sekarang ngikutin JUMLAH PLAYER,
     * bukan fixed 4/dinding. Kiri & kanan diisi duluan sampai penuh (maks
     * 4 cluster/dinding), baru sisanya ke belakang. Tiap cluster = 1
     * player: dikasih backing blue concrete di belakang clue, red concrete
     * di belakang means, plus kepala (skin) player itu ditaro di atas
     * means-nya.
     */
    private void teleportPlayersAndDecorateArena(MinecraftServer server) {
        ServerLevel level = server.overworld();

        List<UUID> allPlayers = new ArrayList<>(registeredPlayers);
        for (UUID uuid : allPlayers) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player != null) {
                player.teleportTo(ARENA_TELEPORT_POS.getX() + 0.5, ARENA_TELEPORT_POS.getY(),
                        ARENA_TELEPORT_POS.getZ() + 0.5);
            }
        }

        // Forensic Scientist gak dapet cluster means/clue di dinding --
        // di-skip dari list yang dipake buat bangun cluster (tapi tetep
        // keteleport ke arena kayak biasa di atas). roleAssignments udah
        // keisi dari computeRoleAssignments() yang dipanggil sebelum method
        // ini (lihat tick()).
        List<UUID> players = new ArrayList<>(allPlayers);
        players.removeIf(uuid -> roleAssignments.get(uuid) == Role.FORENSIC_SCIENTIST);

        // pisahin pool means & clue, masing-masing diacak sekali biar ID
        // yang kepake antar cluster/dinding gak pernah dobel
        List<String> meansPool = new ArrayList<>();
        List<String> cluePool = new ArrayList<>();
        for (String id : ModBlocks.CLUE_IDS) {
            if (id.startsWith("means_")) meansPool.add(id);
            else cluePool.add(id);
        }
        Collections.shuffle(meansPool, shuffleRandom);
        Collections.shuffle(cluePool, shuffleRandom);
        int meansIndex = 0;
        int clueIndex = 0;
        int playerIndex = 0;

        int[] clusterCounts = computeClusterCountsPerWall(players.size()); // {kiri, kanan, belakang}

        for (int wallIdx = 0; wallIdx < ARENA_WALLS.length; wallIdx++) {
            WallSpec wall = ARENA_WALLS[wallIdx];

            for (int[] columns : clusterColumnGroups(wall.length(), clusterCounts[wallIdx])) {
                if (playerIndex >= players.size()) break;
                UUID ownerUuid = players.get(playerIndex++);
                ServerPlayer owner = server.getPlayerList().getPlayer(ownerUuid);

                List<ItemStack> clusterMeans = new ArrayList<>();
                List<ItemStack> clusterClues = new ArrayList<>();

                BlockPos clusterCenter;

                for (int offset : columns) {
                    if (meansIndex >= meansPool.size() || clueIndex >= cluePool.size()) break;

                    int x = wall.alongX() ? wall.center() + offset : wall.fixedCoord();
                    int z = wall.alongX() ? wall.fixedCoord() : wall.center() + offset;

                    BlockPos meansPos = new BlockPos(x, MEANS_Y, z);
                    BlockPos cluePos = new BlockPos(x, CLUE_Y, z);
                    String meansId = meansPool.get(meansIndex++);
                    String clueId = cluePool.get(clueIndex++);

                    placeOnWall(level, meansId, meansPos, wall.facing());
                    placeOnWall(level, clueId, cluePos, wall.facing());

                    clusterOwnerByPos.put(meansPos, ownerUuid);
                    clusterOwnerByPos.put(cluePos, ownerUuid);

                    clusterMeans.add(
                        new ItemStack(ModBlocks.CLUE_BLOCKS.get(meansId).get())
                    );

                    clusterClues.add(
                        new ItemStack(ModBlocks.CLUE_BLOCKS.get(clueId).get())
                    );

                    // backing dinding: merah di belakang means, biru di belakang clue
                    Direction backingDir = wall.facing().getOpposite();
                    level.setBlock(meansPos.relative(backingDir), Blocks.RED_CONCRETE.defaultBlockState(), 3);
                    level.setBlock(cluePos.relative(backingDir), Blocks.BLUE_CONCRETE.defaultBlockState(), 3);
                }

                int mid = columns[columns.length / 2];

                int cx = wall.alongX()
                        ? wall.center() + mid
                        : wall.fixedCoord();

                int cz = wall.alongX()
                        ? wall.fixedCoord()
                        : wall.center() + mid;


                CLUSTERS.put(
                    new BlockPos(cx, CLUE_Y, cz),
                    new ClusterData(
                        ownerUuid,
                        getPlayerName(ownerUuid),
                        new BlockPos(cx, CLUE_Y, cz),
                        clusterMeans,
                        clusterClues
                    )
                );

                spawnOwnerHead(level, ownerUuid, getPlayerName(ownerUuid), owner, wall, columns);
            }
        }
    }

    /**
     * Dipanggil pas registered player LOGIN (lihat DeceptionMod). Kalau
     * game lagi jalan (gak IDLE) dan dia punya cluster (bukan Forensic
     * Scientist yang di-skip), respawn kepalanya pake GameProfile asli dia
     * yang sekarang online -- ganti kepala placeholder (skin default)
     * yang kepasang waktu dia masih offline pas arena di-build.
     */
    public void refreshOwnerHeadSkin(MinecraftServer server, UUID ownerUuid) {
        if (state == State.IDLE) return;
        HeadPlacement placement = headPlacementByOwner.get(ownerUuid);
        if (placement == null) return;
        ServerPlayer player = server.getPlayerList().getPlayer(ownerUuid);
        if (player == null) return;

        spawnOwnerHead(server.overworld(), ownerUuid, getPlayerName(ownerUuid), player, placement.wall(), placement.columns());
    }

    private void placeOnWall(ServerLevel level, String id, BlockPos pos, Direction facing) {
        RegistryObject<Block> holder = ModBlocks.CLUE_BLOCKS.get(id);
        if (holder == null) return;
        BlockState state = holder.get().defaultBlockState()
                .setValue(ClueBlock.FACE, AttachFace.WALL)
                .setValue(ClueBlock.FACING, facing);
        level.setBlock(pos, state, 3);
    }

    /**
     * Taro kepala (skin) player pemilik cluster di atas baris means-nya
     * (HEAD_Y). Karena CLUSTER_WIDTH = 4 (genap), gak ada 1 block yang pas
     * di tengah cluster -- jadi kepalanya diapungkan (pakai item display
     * entity, BUKAN block grid) tepat di garis batas antara 2 block
     * tengah, kaya di foto referensi. Kalau nanti CLUSTER_WIDTH diubah jadi
     * ganjil, rumus ini otomatis jatuh pas di tengah 1 block juga.
     */
    private void spawnOwnerHead(ServerLevel level, UUID ownerUuid, String ownerName, ServerPlayer ownerOnline, WallSpec wall, int[] columns) {
        headPlacementByOwner.put(ownerUuid, new HeadPlacement(wall, columns));

        // kalo sebelumnya udah pernah spawn kepala buat owner ini (misal
        // dipanggil ulang dari refreshOwnerHeadSkin pas dia rejoin), buang
        // dulu entity lama-nya (yang masih pake profile placeholder) biar
        // gak numpuk 2 kepala di posisi yang sama.
        List<UUID> previousEntities = headEntitiesByOwner.remove(ownerUuid);
        if (previousEntities != null) {
            for (UUID id : previousEntities) {
                var old = level.getEntity(id);
                if (old != null) old.discard();
                spawnedHeadEntities.remove(id);
            }
        }
        List<UUID> ownEntities = new ArrayList<>();
        headEntitiesByOwner.put(ownerUuid, ownEntities);

        // titik tengah geometris cluster (dalam koordinat dunia, relatif ke wall.center())
        double centerOffset = columns[0] + CLUSTER_WIDTH / 2.0;

        // dorong dikit dari sisi yang NEMPEL ke dinding solid (backingDir)
        // ke arah dalam ruangan -- boundary-nya ditentuin dari backingStep
        // (sisi cluster yang bersentuhan sama dinding solid di belakangnya),
        // terus digeser dikit (HEAD_SURFACE_INSET) ke arah facing biar gak
        // z-fighting.
        Direction backingDir = wall.facing().getOpposite();
        int backingStep = wall.alongX() ? backingDir.getStepZ() : backingDir.getStepX();
        int facingStep = -backingStep;
        double fixedCoordFlush = wall.fixedCoord() + Math.max(backingStep, 0) + facingStep * HEAD_SURFACE_INSET;

        double headX = wall.alongX() ? wall.center() + centerOffset : fixedCoordFlush;
        double headZ = wall.alongX() ? fixedCoordFlush : wall.center() + centerOffset;
        double headY = HEAD_Y + 0.5;

        ItemStack headStack = new ItemStack(Items.PLAYER_HEAD);
        // kalo lagi online, pake GameProfile asli dia (udah bawa texture
        // properties dari sesi login, langsung muncul skin-nya). Kalo lagi
        // OFFLINE (keluar server pas game jalan), tetep bisa dipasang pake
        // UUID+nama yang udah kesimpen dari pas /deception regis -- cuma
        // skin-nya nunggu resolve async dari Mojang (bisa sempet nongol
        // Steve generic dulu), gak apa-apa daripada kepalanya gaada sama
        // sekali.
        GameProfile profile = ownerOnline != null
                ? ownerOnline.getGameProfile()
                : new GameProfile(ownerUuid, ownerName);
        headStack.getOrCreateTag().put("SkullOwner",
                NbtUtils.writeGameProfile(new CompoundTag(), profile));

        float yaw = wall.facing().toYRot();
        Quaternionf leftRotation = new Quaternionf();

        // Semua field Display entity (item, item_display, billboard,
        // transformation) di-set lewat NBT + Entity#load(), BUKAN lewat
        // setter Java langsung -- di 1.20.1 setter2 itu package-private di
        // mapping vanilla (gak public), sedangkan format NBT di bawah ini
        // 100% sama kayak yang dipake command "/summon item_display" (jadi
        // stabil lintas versi & gak nyentuh kelas client-only sama sekali).
        CompoundTag entityTag = new CompoundTag();
        entityTag.put("item", headStack.save(new CompoundTag()));
        entityTag.putString("item_display", "fixed");
        entityTag.putString("billboard", "fixed");

        CompoundTag transformationTag = new CompoundTag();
        transformationTag.put("translation", floatList(0F, 0F, 0F));
        transformationTag.put("left_rotation", floatList(leftRotation.x, leftRotation.y, leftRotation.z, leftRotation.w));
        transformationTag.put("right_rotation", floatList(0F, 0F, 0F, 1F));
        transformationTag.put("scale", floatList(0.9F, 0.9F, 0.9F));
        entityTag.put("transformation", transformationTag);

        Display.ItemDisplay display = (Display.ItemDisplay) EntityType.ITEM_DISPLAY.create(level);
        if (display == null) return;
        display.load(entityTag);
        display.addTag("deception_display");

        display.setNoGravity(true);
        display.setYRot(yaw);
        display.setPos(headX, headY, headZ);

        level.addFreshEntity(display);
        spawnedHeadEntities.add(display.getUUID());
        ownEntities.add(display.getUUID());
        Display.TextDisplay text = (Display.TextDisplay) EntityType.TEXT_DISPLAY.create(level);
        if (text != null) {
            double offset = 0.08;

            double textX = headX;
            double textY = headY + 0.45;
            double textZ = headZ;

            switch (wall.facing()) {
                case NORTH -> textZ -= offset;
                case SOUTH -> textZ += offset;
                case WEST  -> textX -= offset;
                case EAST  -> textX += offset;
            }

            CompoundTag tag = new CompoundTag();
            tag.putString("text",
            Component.Serializer.toJson(
                Component.literal(ownerName)
            ));
            
            tag.putString("billboard", "fixed");
            tag.putInt("background", 0);      // transparan
            tag.putInt("line_width", 200);
            tag.putByte("see_through", (byte)1);
            tag.putByte("default_background", (byte)0);
            
            text.load(tag);
            text.addTag("deception_display");
            text.setYRot(yaw);
            text.setPos(textX, textY, textZ);

            level.addFreshEntity(text);
            spawnedHeadEntities.add(text.getUUID());
            ownEntities.add(text.getUUID());
        }
    }

    private static ListTag floatList(float... values) {
        ListTag list = new ListTag();
        for (float v : values) {
            list.add(FloatTag.valueOf(v));
        }
        return list;
    }

    // ---------- Tick loop, dipanggil dari server tick event ----------

    public void tick() {
        globalTickCounter++;
        if (state == State.COUNTDOWN) {
            countdownTicks--;
            int secondsLeft = (int) Math.ceil(countdownTicks / 20.0);
            if (secondsLeft != lastCountdownSecondShown && secondsLeft > 0) {
                lastCountdownSecondShown = secondsLeft;
                showCountdownTitle(secondsLeft);
            }
            if (countdownTicks <= 0) {
                computeRoleAssignments();
                teleportPlayersAndDecorateArena(serverRef);
                state = State.SHUFFLE;
                shuffleTicksLeft = SHUFFLE_DURATION_TICKS;
                activeRolePool = computeActiveRolePool();
                for (UUID uuid : registeredPlayers) {
                    ServerPlayer player = serverRef.getPlayerList().getPlayer(uuid);
                    if (player != null) {
                        sendTitle(
                            player,
                            Component.literal("Mengocok Peran").withStyle(ChatFormatting.GOLD),
                            Component.empty(),
                            0, SHUFFLE_DURATION_TICKS, 0
                        );
                    }
                }
            }
        } else if (state == State.SHUFFLE) {
            shuffleTicksLeft--;
            spinRoleTitle();
            if (shuffleTicksLeft <= 0) {
                revealRoles(serverRef);
                startNightSequence(serverRef);
            }
        } else if (state == State.NIGHT) {
            tickNightSequence();
        } else if (state == State.DISCUSS) {
            discussTicksLeft--;
            if (discussTicksLeft <= 0) {
                state = State.RUNNING;
                broadcast(serverRef, Component.literal("Waktu diskusi habis!").withStyle(ChatFormatting.RED));
            }
        }
    }

    private void broadcast(MinecraftServer server, Component message) {
        server.getPlayerList().broadcastSystemMessage(message, false);
    }

    public State getState() {
        return state;
    }
}